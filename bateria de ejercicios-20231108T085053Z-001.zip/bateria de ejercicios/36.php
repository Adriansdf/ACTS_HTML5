<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 36</title>
</head>
    <body>

        <h1>Ejercicio 36</h1>

        

        </form>


        <?php


            for ($i = 1; $i <= 9; $i++) {

                $cuadrado = $i * $i;

                echo "<br> El cuadrado de $i es: ";
                
                echo "<br>".$cuadrado."<br>";
            }


        ?>


    </body>

    

</html>
