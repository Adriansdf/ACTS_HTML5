<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 6</title>
</head>
    <body>

    <?php

    

        $VARIABLE = 1234; 
        echo "<br>";
        

        $HOLA = 532; 
        echo "<br>";
        

        echo $VARIABLE - $HOLA;
        echo "<br>";

    ?>





        
    </body>
</html>