<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 30</title>
</head>
    <body>

        <h1> ESTE NOO SE HACEE ; </h1>

        <form action="30.php" method="post"> 

            
        </form>

        <?php

            
            


        ?>

    </body>

    

</html>