<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
    <body>

    <?php

        $VARIABLE = 273; 
        echo "<br>";
        echo $VARIABLE;
        echo "<br>";

        $VARIABLE = 597; 
        echo "<br>";
        echo $VARIABLE;
        echo "<br>";

    ?>





        
    </body>
</html>