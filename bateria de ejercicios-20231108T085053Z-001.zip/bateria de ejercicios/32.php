<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 32</title>
</head>
    <body>

        <h1>Ejercicio 32</h1>

        

        </form>

        <?php

            
            $numero;

            for ($i = 0; $i <= 9; $i++) {
                
                echo "<br>".$i;
            }
            
            


        ?>

    </body>

    

</html>